import sys, os
sys.path.append(os.path.dirname(__file__))
sys.path.append(os.path.join(os.path.dirname(__file__), 'third_party/fast-reid'))

__version__='0.3.2.0'