import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../third_party/fast-reid")))
