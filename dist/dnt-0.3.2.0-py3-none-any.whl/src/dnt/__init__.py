"""DNT package for detection and tracking.

This package provides detection and tracking functionality.
"""

import os
import sys

sys.path.append(os.path.dirname(__file__))

__version__ = "0.3.2.0"
