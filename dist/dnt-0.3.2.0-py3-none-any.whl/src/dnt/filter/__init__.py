"""Filter package for detection tracking."""

import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__)))

from .filter import Filter as Filter
